
  # 医学院虚拟实验平台设计

  This is a code bundle for 医学院虚拟实验平台设计. The original project is available at https://www.figma.com/design/RlfrpeAItD382K40lsc19H/%E5%8C%BB%E5%AD%A6%E9%99%A2%E8%99%9A%E6%8B%9F%E5%AE%9E%E9%AA%8C%E5%B9%B3%E5%8F%B0%E8%AE%BE%E8%AE%A1.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  